Tugas clustering (unsupervised Learning) adalah mengelompokkan pelanggan berdasarkan data pelanggan di dealer tanpa memperhatikan label kelas apakah pelanggan tertarik untuk membeli kendaraan baru atau tidak. 

Tugas classification (supervised learning) adalah memprediksi apakah pelanggan tertarik untuk membeli kendaraan baru atau tidak berdasarkan data pelanggan di dealer.


SIM	--> 0 : Tidak punya SIM 1 : Punya SIM
Kode_Daerah --> Kode area tempat tinggal pelanggan
Sudah_Asuransi --> 1 : Pelanggan sudah memiliki asuransi kendaraan, 0 : Pelanggan belum memiliki asuransi kendaraan
Umur_Kendaraan --> Umur kendaraan
Kendaraan_Rusak --> 1 : Kendaraan pernah rusak sebelumnya. 0 : Kendaraan belum pernah rusak.
Premi --> Jumlah premi yang harus dibayarkan per tahun.
Kanal_Penjualan --> Kode kanal untuk menghubungi pelanggan (email, telpon, dll)
Lama_Berlangganan	--> Sudah berapa lama pelanggan menjadi klien perusahaan
Tertarik --> 1 : Pelanggan tertarik, 0 : Pelanggan tidak tertarik